import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class FuncCompTable extends JTable {

	private static int n_col_hdr;

	public FuncCompTable(DefaultTableModel model) {
        // table construction
        super();
		n_col_hdr = 7;
        setModel(model); 	
	}

    @Override
    public Class getColumnClass(int column) {     
        if (column > n_col_hdr) {
            return Boolean.class;
        } else {
            return String.class;
        }
    }  

}